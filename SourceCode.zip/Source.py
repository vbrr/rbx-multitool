import os,time,sys,webbrowser,requests,getpass

#colorama
try:
    import colorama
except ModuleNotFoundError:
    os.system("pip3 install colorama")
import colorama
from colorama import Fore
colorama.init(autoreset=True)

# clearconsole
def clearConsole(): return os.system(
    'cls' if os.name in ('nt', 'dos') else 'clear')

one = print("\037[1;36;40m","1")

def main():

    os.system("title ")
    os.system('mode con: cols=49 lines=13')

    
    print(f"{Fore.CYAN}-------------------------------------------------")
    print(f"{Fore.LIGHTWHITE_EX}                 Roblox MultiTool")
    print()
    print()
    print(f"            {Fore.WHITE}[{Fore.LIGHTYELLOW_EX}1{Fore.WHITE}] Fix Client Behaviour")
    print(f"            {Fore.WHITE}[{Fore.LIGHTYELLOW_EX}2{Fore.WHITE}] Hwid ban bypass tool")
    print(f"            {Fore.WHITE}[{Fore.LIGHTYELLOW_EX}3{Fore.WHITE}] Whatexploitsare.online")
    print(f"            {Fore.WHITE}[{Fore.LIGHTYELLOW_EX}4{Fore.WHITE}] Reinstall roblox")
    print(f"            {Fore.WHITE}[{Fore.LIGHTYELLOW_EX}5{Fore.WHITE}] Open Credits")
    print()
    print()
    print(f"{Fore.CYAN}-------------------------------------------------")

    opt = input()

    if opt == ("1"):
        clearConsole()
        print(f"{Fore.CYAN}-------------------------------------------------")
        print(f"{Fore.LIGHTWHITE_EX}                 Roblox MultiTool")
        print()
        print("                  Removing Files")
        print("            GlobalBasicSettings_13.xml")
        print("              AnalysticsSettings.xml")
        print("                     frm.cfg")
        print()
        print()
        print()
        print()
        print(f"{Fore.CYAN}-------------------------------------------------")
        time.sleep(2)
        from os.path import exists
        appdatapath = f"C:/Users/{getpass.getuser()}/AppData/Local"
        if exists(f"{appdatapath}/Roblox/GlobalBasicSettings_13.xml"):
            os.remove(f"{appdatapath}/Roblox/GlobalBasicSettings_13.xml")
        if exists(f"{appdatapath}/Roblox/GlobalSettings_13.xml"):
            os.remove(f"{appdatapath}/Roblox/GlobalSettings_13.xml")
        if exists(f"{appdatapath}/Roblox/frm.cfg"):
            os.remove(f"{appdatapath}/Roblox/frm.cfg")
            time.sleep(2)
            clearConsole()
            print(f"{Fore.CYAN}-------------------------------------------------")
            print(f"{Fore.LIGHTWHITE_EX}                 Roblox MultiTool")
            print()
            print("                Operation complete!")
            print("            You will not be redirected.")
            print()
            print()
            print()
            print()
            print()
            print()
            print(f"{Fore.CYAN}-------------------------------------------------")
            time.sleep(3)
            clearConsole()
            main()
        else:
            clearConsole()
            print(f"{Fore.CYAN}-------------------------------------------------")
            print(f"{Fore.LIGHTWHITE_EX}                 Roblox MultiTool")
            print()
            print("       The issue has already been resolved")
            print()
            print()
            print()
            print()
            print()
            print()
            print()
            print(f"{Fore.CYAN}-------------------------------------------------")
            time.sleep(3)
            clearConsole()
            main()

    if opt == ("2"):
        clearConsole()
        print(f"{Fore.CYAN}-------------------------------------------------")
        print(f"{Fore.LIGHTWHITE_EX}                 Roblox MultiTool")
        print()
        print("    Checking if the bypass dll can be located")
        print()
        print()
        print()
        print()
        print()
        print()
        print()
        print(f"{Fore.CYAN}-------------------------------------------------")
        time.sleep(2)

        def download(link, path):
            try:
                r = requests.get(link, allow_redirects=True)
            except Exception as e:
                print(e)
            open(path, 'wb').write(r.content)
        ver = requests.get("http://setup.roblox.com/version").content
        from os.path import exists
        appdatapath = f"C:/Users/{getpass.getuser()}/AppData/Local"
        if exists(f"{appdatapath}/Roblox/Versions/"+str(ver, "utf-8")+"/XInput1_4.dll") == True:
            clearConsole()
            print(f"{Fore.CYAN}-------------------------------------------------")
            print(f"{Fore.LIGHTWHITE_EX}                 Roblox MultiTool")
            print()
            print("    Checking if the bypass dll can be located")
            print("             Bypass is already setup")
            print()
            print()
            print()
            print()
            print()
            print()
            print(f"{Fore.CYAN}-------------------------------------------------")
            time.sleep(2)
            clearConsole()
            main()
        elif exists(f"{appdatapath}/Roblox/Versions/"+str(ver, "utf-8")+"/XInput1_4.dll") == False:
            clearConsole()
            print(f"{Fore.CYAN}-------------------------------------------------")
            print(f"{Fore.LIGHTWHITE_EX}                 Roblox MultiTool")
            print()
            print("    Checking if the bypass dll can be located")
            print("            File could not be located!")
            print()
            print()
            print()
            print()
            print()
            print()
            print(f"{Fore.CYAN}-------------------------------------------------")
            time.sleep(2)
            clearConsole()
            print(f"{Fore.CYAN}-------------------------------------------------")
            print(f"{Fore.LIGHTWHITE_EX}                 Roblox MultiTool")
            print()
            print("           Downloading the required dll")
            print()
            print()
            print()
            print()
            print()
            print()
            print()
            print(f"{Fore.CYAN}-------------------------------------------------")
            time.sleep(2)
            download("https://github.com/gogo9211/Roblox-Woof/releases/download/release/XInput1_4.dll",
                    f"{appdatapath}/Roblox/versions/"+str(ver, "utf-8")+"/XInput1_4.dll")
            if exists(f"{appdatapath}/Roblox/Versions/"+str(ver, "utf-8")+"/XInput1_4.dll"):
                time.sleep(3)
                clearConsole()
                print(f"{Fore.CYAN}-------------------------------------------------")
                print(f"{Fore.LIGHTWHITE_EX}                 Roblox MultiTool")
                print()
                print("           Downloading the required dll")
                print("            Bypass successfully setup!")
                print()
                print()
                print()
                print()
                print()
                print()
                print(f"{Fore.CYAN}-------------------------------------------------")
                time.sleep(3)
                clearConsole()
                main()
            elif exists(f"{appdatapath}/Roblox/Versions/"+str(ver, "utf-8")+"/XInput1_4.dll") == False:
                time.sleep(2)
                clearConsole()
                print(f"{Fore.CYAN}-------------------------------------------------")
                print(f"{Fore.LIGHTWHITE_EX}                 Roblox MultiTool")
                print()
                print("           Downloading the required dll")
                print("       There was an issue while downloading...")
                print()
                print()
                print()
                print()
                print()
                print()
                print(f"{Fore.CYAN}-------------------------------------------------")
                time.sleep(3)
                clearConsole()
                main()

    if opt == ("3"):
        clearConsole()
        print(f"{Fore.CYAN}-------------------------------------------------")
        print(f"{Fore.LIGHTWHITE_EX}                 Roblox MultiTool")
        print()
        print("                Redirecting you to")
        print("              whatexploitsare.online")
        print()
        print()
        print()
        print()
        print()
        print()
        print(f"{Fore.CYAN}-------------------------------------------------")
        time.sleep(1)
        webbrowser.open("https://whatexploitsare.online")
        time.sleep(4)
        clearConsole()
        main()

    if opt == ("4"):
        clearConsole()
        print(f"{Fore.CYAN}-------------------------------------------------")
        print(f"{Fore.LIGHTWHITE_EX}                 Roblox MultiTool")
        print()
        print("                Downloading roblox")
        print("              This may take a while..")
        print()
        print()
        print()
        print()
        print()
        print()
        print(f"{Fore.CYAN}-------------------------------------------------")

        def download(link, path):
            try:
                r = requests.get(link, allow_redirects=True)
            except Exception as e:
                print(e)
            open(path, 'wb').write(r.content)
        ver = requests.get("http://setup.roblox.com/version").content
        download("https://setup.rbxcdn.com/"+str(ver, "utf-8")+"-Roblox.exe",
                os.path.abspath(os.getcwd()) + "/RobloxPlayerLauncher.exe")
        time.sleep(2)
        from os.path import exists
        appdatapath = f"C:/Users/{getpass.getuser()}/AppData/Local"
        if exists(f"{appdatapath}/Roblox/"):
            os.startfile(os.path.abspath(os.getcwd()) +
                        "/RobloxPlayerLauncher.exe")
            time.sleep(2)
            clearConsole()
            print(f"{Fore.CYAN}-------------------------------------------------")
            print(f"{Fore.LIGHTWHITE_EX}                 Roblox MultiTool")
            print()
            print("                Running installer..")
            print()
            print()
            print()
            print()
            print()
            print()
            print()
            print(f"{Fore.CYAN}-------------------------------------------------")
            time.sleep(4)
            clearConsole()
            print(f"{Fore.CYAN}-------------------------------------------------")
            print(f"{Fore.LIGHTWHITE_EX}                 Roblox MultiTool")
            print()
            print("                Running installer..")
            print("      Roblox has been successfully Installed!")
            print()
            print()
            print()
            print()
            print()
            print()
            print(f"{Fore.CYAN}-------------------------------------------------")
            time.sleep(3)
            clearConsole()
            main()
        else:
            clearConsole()
            from os.path import exists
            if exists(os.path.abspath(os.getcwd()) +
                        "/RobloxPlayerLauncher.exe"):
                print(f"{Fore.CYAN}-------------------------------------------------")
                print(f"{Fore.LIGHTWHITE_EX}                 Roblox MultiTool")
                print()
                print("                Running installer..")
                print()
                print()
                print()
                print()
                print()
                print()
                print()
                print(f"{Fore.CYAN}-------------------------------------------------")
                os.startfile(os.path.abspath(os.getcwd()) +
                        "/RobloxPlayerLauncher.exe")
            time.sleep(4)
            def download(link, path):
                try:
                    r = requests.get(link, allow_redirects=True)
                except Exception as e:
                    print(e)
                open(path, 'wb').write(r.content)
            ver = requests.get("http://setup.roblox.com/version").content
            appdatapath = f"C:/Users/{getpass.getuser()}/AppData/Local"
            from os.path import exists
            if exists(f"{appdatapath}/Roblox/Versions/"+str(ver, "utf-8")+"/RobloxPlayerBeta.exe"):
                os.remove(f"{appdatapath}/Roblox/Versions/"+str(ver, "utf-8")+"/RobloxPlayerBeta.exe")
            time.sleep(3)
            if exists(f"{appdatapath}/Roblox/Versions/"+str(ver, "utf-8")+"/RobloxPlayerBeta.exe") == True:
                clearConsole()
                print(f"{Fore.CYAN}-------------------------------------------------")
                print(f"{Fore.LIGHTWHITE_EX}                 Roblox MultiTool")
                print()
                print("                Running installer..")
                print("      Roblox has been successfully Installed!")
                print()
                print()
                print()
                print()
                print()
                print()
                print(f"{Fore.CYAN}-------------------------------------------------")
                time.sleep(3)
                clearConsole()
                main()


    if opt == ("5"):
        os.system('mode con: cols=50 lines=17')
        clearConsole()
        print(f"{Fore.CYAN}--------------------------------------------------")
        print(f"{Fore.LIGHTWHITE_EX}                     Credits")
        print()
        print()
        print(f"             {Fore.LIGHTWHITE_EX}brr#4379 {Fore.LIGHTYELLOW_EX}- {Fore.LIGHTWHITE_EX}Main Developer")
        print(f"   {Fore.LIGHTWHITE_EX}SimplyDeveloper {Fore.LIGHTYELLOW_EX}- {Fore.LIGHTWHITE_EX}Support during development")
        print(f"   {Fore.LIGHTWHITE_EX}BabyHamsta {Fore.LIGHTYELLOW_EX}- {Fore.LIGHTWHITE_EX}Owner of whatexploitsare.online")
        print(f"    {Fore.LIGHTWHITE_EX}0x90, gogo and iivillian {Fore.LIGHTYELLOW_EX}- {Fore.LIGHTWHITE_EX}Hwid Ban bypass")
        print()
        print()
        print()
        print(f"           {Fore.LIGHTBLACK_EX}Press Y to leave the credits          ")
        print()
        print()
        print(f"                  {Fore.LIGHTWHITE_EX}Version 2.1.0")
        print(f"{Fore.CYAN}--------------------------------------------------")
        inp = input()
        if inp == ("y"):
            clearConsole()
            main()
        time.sleep(9999)
        sys.exit()
        
    if opt != ("1") or opt != ("2") or opt != ("3") or opt != ("4") or opt != ("5"):
        clearConsole()
        main()
main()